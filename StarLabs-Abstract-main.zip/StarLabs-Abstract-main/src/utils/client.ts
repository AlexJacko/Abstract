import type { Got, Headers } from "got";
import { HttpsProxyAgent } from "https-proxy-agent";
import { SocksProxyAgent } from "socks-proxy-agent";
import { generateCsrfToken } from "./random.js";
const USER_AGENT =
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/132.0.0.0 Safari/537.36";

const DEFAULT_HEADERS: Headers = {
    accept: "*/*",
    "accept-language":
        "en-GB,en-US;q=0.9,en;q=0.8,ru;q=0.7,zh-TW;q=0.6,zh;q=0.5",
    "content-type": "application/json",
    priority: "u=1, i",
    "sec-ch-ua":
        '"Not A(Brand";v="8", "Chromium";v="132", "Google Chrome";v="132"',
    "sec-ch-ua-mobile": "?0",
    "sec-ch-ua-platform": '"Windows"',
    "sec-fetch-dest": "empty",
    "sec-fetch-mode": "cors",
    "sec-fetch-site": "cross-site",
    "user-agent": USER_AGENT,
};

interface RequestOptions {
    headers?: Record<string, string>;
    json?: any;
}

interface Response {
    ok: boolean;
    text(): Promise<string>;
    json(): Promise<any>;
}

export class Client {
    private readonly proxy?: string;
    public client!: Got;
    public generatedCsrfToken: string | undefined;

    constructor(proxy?: string) {
        this.proxy = proxy;
    }

    /**
     * Initializes the client with got instance
     */
    async init(): Promise<void> {
        const { default: got } = await import("got");
        this.client = got.extend({
            headers: DEFAULT_HEADERS,
            timeout: { request: 30000 },
            http2: true,
            followRedirect: true,
            retry: { limit: 2 },
            // cookieJar: new CookieJar(),
        });
    }

    /**
     * Creates and configures the HTTP client
     */
    async createClient(proxyType: "http" | "socks" = "http"): Promise<Got> {
        if (!this.client) {
            await this.init();
        }

        if (this.proxy) {
            const { success, instance } = await this.setProxyOnClient(
                this.proxy,
                proxyType
            );
            if (success) {
                this.client = instance;
            }
        }
        return this.client;
    }

    /**
     * Creates a Twitter-specific client with authentication
     */
    async createTwitterClient(authToken: string): Promise<Got> {
        this.generatedCsrfToken = generateCsrfToken();

        return this.client.extend({
            headers: {
                ...this.getTwitterHeaders({
                    ct0: this.generatedCsrfToken,
                    auth_token: authToken,
                }),
                cookie: `lang=en; auth_token=${authToken}; ct0=${this.generatedCsrfToken};`,
            },
        });
    }

    private async setProxyOnClient(
        proxy: string,
        proxyType: "http" | "socks"
    ): Promise<{ success: boolean; instance: Got }> {
        let agent;

        switch (proxyType) {
            case "http":
                agent = new HttpsProxyAgent(`http://${proxy}`);
                break;
            case "socks":
                agent = new SocksProxyAgent(`socks://${proxy}`);
                break;
            default:
                return { success: false, instance: this.client };
        }

        const clientWithProxy = this.client.extend({
            agent: {
                http: agent,
                https: agent,
            },
        });

        return { success: true, instance: clientWithProxy };
    }

    private getTwitterHeaders(cookies: Record<string, string>): Headers {
        return {
            authorization:
                "Bearer AAAAAAAAAAAAAAAAAAAAANRILgAAAAAAnNwIzUejRCOuH5E6I8xnZz4puTs=1Zv7ttfk8LF81IUq16cHjhLTvJu4FA33AGWWjCpTnA",
            referer: "https://x.com/",
            "user-agent": USER_AGENT,
            "x-csrf-token": cookies.ct0 || "",
            "x-twitter-auth-type": cookies.auth_token ? "OAuth2Session" : "",
            "x-twitter-active-user": "yes",
            "x-twitter-client-language": "en",
        };
    }

    async get(url: string, options?: RequestOptions): Promise<Response> {
        try {
            const response = await fetch(url, {
                method: "GET",
                headers: {
                    ...options?.headers,
                },
            });

            return response;
        } catch (error) {
            throw new Error(`GET request failed: ${error}`);
        }
    }

    async post(url: string, options?: RequestOptions): Promise<Response> {
        try {
            const response = await fetch(url, {
                method: "POST",
                headers: {
                    "Content-Type": "application/json",
                    ...options?.headers,
                },
                body: options?.json ? JSON.stringify(options.json) : undefined,
            });

            return response;
        } catch (error) {
            throw new Error(`POST request failed: ${error}`);
        }
    }
}
