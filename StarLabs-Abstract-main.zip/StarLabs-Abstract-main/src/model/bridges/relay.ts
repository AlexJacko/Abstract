import { ethers } from "ethers";
import { Config } from "../../utils/config.js";
import logger from "../../utils/logger.js";

interface QuoteData {
    steps: {
        items: {
            data: {
                to: string;
                value: string;
                data: string;
                chainId: string;
                maxFeePerGas: string;
                maxPriorityFeePerGas: string;
            };
        }[];
    }[];
}

// Add interface for transaction type
interface RelayTransaction {
    from: string;
    to: string;
    value: bigint;
    data: string;
    chainId: number;
    maxFeePerGas: bigint;
    maxPriorityFeePerGas: bigint;
    nonce: number;
    type: number;
    gasLimit?: bigint; // Make gasLimit optional since we'll add it later
}

export class RelayBridge {
    private provider: ethers.JsonRpcProvider;
    private wallet: ethers.Wallet;
    private quoteData: QuoteData | null = null;

    constructor(
        private accountIndex: number,
        private proxy: string,
        private privateKey: string,
        private config: Config,
        private abstractAddress: string
    ) {
        this.provider = new ethers.JsonRpcProvider(
            this.config.rpcs.arbitrum_rpc[0]
        );
        this.wallet = new ethers.Wallet(privateKey, this.provider);
    }

    /**
     * Get quote from Relay API
     * @returns true if successful, false otherwise
     */
    async quote(ethAmount: string): Promise<boolean> {
        try {
            logger.info(`${this.wallet.address} | Getting quote from Relay`);

            const headers = {
                accept: "application/json",
                "content-type": "application/json",
                "user-agent":
                    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/132.0.0.0 Safari/537.36",
            };

            const jsonData = {
                user: this.wallet.address.toLowerCase(),
                originChainId: 42161,
                destinationChainId: 2741,
                originCurrency: "0x0000000000000000000000000000000000000000",
                destinationCurrency:
                    "0x0000000000000000000000000000000000000000",
                recipient: this.abstractAddress,
                tradeType: "EXACT_INPUT",
                amount: ethAmount,
                referrer: "relay.link/swap",
                useExternalLiquidity: false,
                useDepositAddress: false,
            };

            const response = await fetch("https://api.relay.link/quote", {
                method: "POST",
                headers,
                body: JSON.stringify(jsonData),
            });

            if (response.ok) {
                this.quoteData = await response.json();
                logger.success(
                    `${this.wallet.address} | Successfully got quote from Relay`
                );
                return true;
            } else {
                const errorText = await response.text();
                logger.error(
                    `${this.wallet.address} | Failed to get quote from Relay: ${errorText}`
                );
                return false;
            }
        } catch (error) {
            logger.error(
                `${this.wallet.address} | Error getting quote from Relay: ${error}`
            );
            return false;
        }
    }

    /**
     * Bridge ETH using Relay
     * @returns true if successful, false otherwise
     */
    async bridge(): Promise<boolean> {
        try {
            if (!this.quoteData) {
                logger.error(
                    `${this.wallet.address} | No quote data available. Please run quote() first`
                );
                return false;
            }

            // Extract transaction data from quote
            const txData = this.quoteData.steps[0].items[0].data;

            // Prepare transaction with proper typing
            const transaction: RelayTransaction = {
                from: this.wallet.address,
                to: ethers.getAddress(txData.to),
                value: BigInt(txData.value),
                data: txData.data,
                chainId: parseInt(txData.chainId),
                maxFeePerGas: BigInt(txData.maxFeePerGas),
                maxPriorityFeePerGas: BigInt(txData.maxPriorityFeePerGas),
                nonce: await this.wallet.getNonce(),
                type: 2, // EIP-1559 transaction
            };

            // Estimate gas
            const gasEstimate = await this.provider.estimateGas(transaction);
            transaction.gasLimit = (gasEstimate * BigInt(110)) / BigInt(100); // Add 10% buffer

            // Send transaction
            const tx = await this.wallet.sendTransaction(transaction);
            logger.info(
                `${this.wallet.address} | Bridge transaction sent: ${tx.hash}`
            );

            // Wait for receipt
            const receipt = await tx.wait();

            if (receipt && receipt.status === 1) {
                logger.success(
                    `${this.wallet.address} | Bridge transaction confirmed: https://arbiscan.io/tx/${tx.hash}`
                );
                return true;
            } else {
                logger.error(
                    `${this.wallet.address} | Bridge transaction failed: ${tx.hash}`
                );
                return false;
            }
        } catch (error) {
            logger.error(`${this.wallet.address} | Error in bridge: ${error}`);
            return false;
        }
    }
}
