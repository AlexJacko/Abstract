import { ethers } from "ethers";
import { Config } from "../../utils/config.js";
import { Client } from "../../utils/client.js";
import {
    ABS_BADGE_CONTRACT,
    ABS_VOTE_CONTRACT,
    EXPLORER_URL,
    PRIVY_APP_ID,
    PRIVY_CLIENT_ID,
    SWAP_TOKENS,
} from "./constants.js";
import {
    getRandomRpc,
    randomItemFromArray,
    generateCsrfToken,
    sleep,
    randomSleep,
} from "../../utils/random.js";
import logger from "../../utils/logger.js";
import crypto, { randomInt } from "crypto";
import { createAbstractClient } from "@abstract-foundation/agw-client";
import { http } from "viem";
import { privateKeyToAccount } from "viem/accounts";
import { abstract } from "viem/chains";
import fs from "fs";
import { BitgetWithdraw } from "../cex_withdraw/bitget.js";
import { OKXWithdraw } from "../cex_withdraw/okx.js";
import { RelayBridge } from "../bridges/relay.js";
import { savePrivyPrivateKey } from "../../utils/writer.js";
import { PrivateKeyGrabber } from "./private_key_grabber.js";

interface LoginTokens {
    bearer_token: string;
    privy_access_token: string;
    refresh_token: string;
    identity_token: string;
    userLogin: string;
}

interface DeviceData {
    device_id: string;
    device_auth_share: string;
    recovery_auth_share: string;
    encrypted_recovery_share: string;
    encrypted_recovery_share_iv: string;
    recovery_type: string;
    recovery_key_hash: string;
    imported: boolean;
    recovery_key: string;
}

interface UserInfoResponse {
    user: {
        walletAddress: string;
    };
}

interface AbsBalance {
    name: string;
    symbol: string;
    decimals: number;
    rawBalance: string;
    decimalBalance: string;
    usdValue: number;
}

interface UserInfo {
    user: {
        walletAddress: string;
        socials: {
            discord?: string;
            twitter?: string;
        };
        badges: {
            badge: {
                id: number;
                type: string;
                name: string;
                icon: string;
                description: string;
                requirement: string;
            };
            claimed: boolean;
        }[];
    };
}

// Add token symbol mapping at the top with other constants
const TOKEN_SYMBOL_MAPPING: { [key: string]: string } = {
    "USDC.e": "USDC",
    // Add other mappings if needed
};

export class AbstractAccount {
    private wallet: ethers.Wallet;
    private provider: ethers.JsonRpcProvider;
    public address: string;
    private abstractAccount: any;
    public loginTokens: LoginTokens = {
        bearer_token: "",
        privy_access_token: "",
        refresh_token: "",
        identity_token: "",
        userLogin: "",
    };
    private embeddedWalletAddress: string = "";

    constructor(
        private accountIndex: number,
        private proxy: string,
        private privateKey: string,
        private privyPrivateKey: string,
        private twitterToken: string,
        private discordToken: string,
        private config: Config,
        private httpClient: Client
    ) {
        // Initialize provider
        this.provider = new ethers.JsonRpcProvider(
            getRandomRpc(config.rpcs.abstract_rpc)
        );

        // Initialize wallet with provider
        this.wallet = new ethers.Wallet(privateKey, this.provider);
        this.address = this.wallet.address;
    }

    // Add helper function at the top level of the class
    private async retryOperation(
        operation: () => Promise<boolean>,
        actionName: string
    ): Promise<boolean> {
        for (
            let attempt = 1;
            attempt <= this.config.settings.attempts;
            attempt++
        ) {
            try {
                const result = await operation();
                if (result) {
                    if (attempt > 1) {
                        logger.success(
                            `${this.accountIndex} | ${this.address} | ${actionName} succeeded on attempt ${attempt}`
                        );
                    }
                    return true;
                }
            } catch (error) {
                logger.error(
                    `${this.accountIndex} | ${this.address} | ${actionName} attempt ${attempt} failed: ${error}`
                );
            }

            if (attempt < this.config.settings.attempts) {
                logger.info(
                    `${this.accountIndex} | ${
                        this.address
                    } | Retrying ${actionName} (attempt ${attempt + 1}/${
                        this.config.settings.attempts
                    })`
                );
                await sleep(5000); // Wait 5 seconds between retries
            }
        }

        logger.error(
            `${this.accountIndex} | ${this.address} | ${actionName} failed after ${this.config.settings.attempts} attempts`
        );
        return false;
    }

    /**
     * Main login flow
     */
    async login(): Promise<boolean> {
        try {
            const nonce = await this._getNonce();
            const date = new Date();
            const currentTime =
                date.getUTCFullYear() +
                "-" +
                String(date.getUTCMonth() + 1).padStart(2, "0") +
                "-" +
                String(date.getUTCDate()).padStart(2, "0") +
                "T" +
                String(date.getUTCHours()).padStart(2, "0") +
                ":" +
                String(date.getUTCMinutes()).padStart(2, "0") +
                ":" +
                String(date.getUTCSeconds()).padStart(2, "0") +
                ".604Z";

            const signatureText =
                `www.abs.xyz wants you to sign in with your Ethereum account:\n` +
                `${this.address}\n\n` +
                `By signing, you are proving you own this wallet and logging in. This does not initiate a transaction or cost any fees.\n\n` +
                `URI: https://www.abs.xyz\n` +
                `Version: 1\n` +
                `Chain ID: 2741\n` +
                `Nonce: ${nonce}\n` +
                `Issued At: ${currentTime}\n` +
                `Resources:\n` +
                `- https://privy.io`;

            const signature = await this.wallet.signMessage(signatureText);

            const headers = {
                accept: "application/json",
                origin: "https://www.abs.xyz",
                "privy-app-id": PRIVY_APP_ID,
                "privy-client-id": PRIVY_CLIENT_ID,
                referer: "https://www.abs.xyz/",
            };
            const jsonData = {
                message: signatureText,
                signature,
                chainId: "eip155:2741",
                walletClientType: "metamask",
                connectorType: "injected",
                mode: "login-or-sign-up",
            };

            const response = await this.httpClient.post(
                "https://auth.privy.io/api/v1/siwe/authenticate",
                { headers, json: jsonData }
            );

            if (!response.ok) {
                throw new Error(`Failed to login: ${await response.text()}`);
            }

            const data = await response.json();

            this.loginTokens = {
                ...this.loginTokens,
                bearer_token: data.token,
                privy_access_token: data.privy_access_token,
                refresh_token: data.refresh_token,
                identity_token: data.identity_token,
            };

            if (data.is_new_user) {
                logger.success(
                    `${this.accountIndex} | ${this.address} | Successfully registered new account!`
                );
            } else {
                logger.success(
                    `${this.accountIndex} | ${this.address} | Successfully logged in!`
                );
            }

            if (!(await this._refreshSession())) {
                return false;
            }

            if (!(await this._refreshSession())) {
                return false;
            }

            if (this.privyPrivateKey === "") {
                const grabber = new PrivateKeyGrabber(
                    this.accountIndex,
                    this.proxy,
                    this.privateKey
                );
                this.privyPrivateKey = await grabber.grabPrivateKey();
                if (this.privyPrivateKey === "") {
                    logger.error(
                        `${this.address} | Error grabbing private key`
                    );
                    return false;
                } else {
                    if (!this.config.mutex) {
                        logger.error(
                            `${this.address} | Mutex is not initialized`
                        );
                        return false;
                    }
                    await savePrivyPrivateKey(
                        this.config.mutex,
                        "data/private_keys.txt",
                        this.privateKey,
                        this.privyPrivateKey
                    );
                }
            }

            const userInfo = await this._getUserInfo();
            this.embeddedWalletAddress = userInfo.user.walletAddress;

            try {
                // Initialize Abstract Account client
                // Ensure private key is in correct format for viem
                const formattedPrivyKey = this.privyPrivateKey.startsWith("0x")
                    ? this.privyPrivateKey
                    : `0x${this.privyPrivateKey}`;

                // Create signer account
                const agwSigner = privateKeyToAccount(
                    formattedPrivyKey as `0x${string}`
                );

                this.abstractAccount = await createAbstractClient({
                    signer: agwSigner,
                    chain: abstract,
                    transport: http(),
                });

                logger.success(
                    `${this.accountIndex} | ${this.address} | Successfully initialized Abstract Account`
                );
            } catch (error) {
                logger.error(
                    `${this.accountIndex} | ${this.address} | Error initializing Abstract Account: ${error}`
                );
                return false;
            }

            return true;
        } catch (error) {
            logger.error(
                `${this.accountIndex} | ${this.address} | Error login abs: ${error}`
            );
            return false;
        }
    }

    // Helper function to format balances for logging
    private formatBalances(balances: AbsBalance[]): string {
        return balances
            .map(
                (b) =>
                    `${b.symbol}: ${b.decimalBalance} ($${b.usdValue.toFixed(
                        2
                    )})`
            )
            .join(" | ");
    }

    // Helper function to format USD values for logging
    private formatUsdValues(balances: AbsBalance[]): string {
        return balances
            .map((b) => `${b.symbol}: $${b.usdValue.toFixed(2)}`)
            .join(" | ");
    }

    async swaps(): Promise<boolean> {
        return await this.retryOperation(async () => {
            try {
                // Initial balance check
                const initialBalances = await this._getAbsWalletBalances();
                if (!initialBalances || initialBalances.length === 0) {
                    logger.info(
                        `${this.accountIndex} | ${this.address} | No tokens found in Abstract wallet, initiating bridge...`
                    );
                    // Check and bridge ETH if needed
                    const result = await this._bridge();
                    if (!result) {
                        logger.error(
                            `${this.accountIndex} | ${this.address} | Failed to bridge ETH to Abstract`
                        );
                        return false;
                    }

                    logger.info(
                        `${this.accountIndex} | ${this.address} | Waiting 30 seconds for tokens to appear in Abstract wallet...`
                    );
                    await sleep(30000);

                    const newBalances = await this._getAbsWalletBalances();
                    if (!newBalances || newBalances.length === 0) {
                        logger.error(
                            `${this.accountIndex} | ${this.address} | Still no tokens after bridge`
                        );
                        return false;
                    }
                }

                logger.info(
                    `${this.accountIndex} | ${
                        this.address
                    } | Initial balances: ${this.formatBalances(
                        initialBalances!
                    )}`
                );

                const numberOfSwaps = randomInt(
                    this.config.abs.number_of_swaps[0],
                    this.config.abs.number_of_swaps[1] + 1
                );

                logger.info(
                    `${this.accountIndex} | ${this.address} | Will perform ${numberOfSwaps} swaps`
                );

                for (
                    let swapCount = 0;
                    swapCount < numberOfSwaps;
                    swapCount++
                ) {
                    let success = false;
                    for (let attempt = 0; attempt < 3 && !success; attempt++) {
                        try {
                            let balances = await this._getAbsWalletBalances();
                            if (!balances) {
                                continue;
                            }


                            // Find token with highest USD value
                            const highestBalanceToken = balances.reduce(
                                (max, current) => {
                                    return current.usdValue > max.usdValue
                                        ? current
                                        : max;
                                },
                                balances[0]
                            );

                            if (
                                highestBalanceToken.usdValue <
                                this.config.abs.minimal_usd_balance
                            ) {
                                // Add a small delay before checking Arbitrum balance
                                await sleep(5000);

                                // Check Arbitrum balance
                                const randomRpc = getRandomRpc(
                                    this.config.rpcs.arbitrum_rpc
                                );
                                const arbitrumProvider =
                                    new ethers.JsonRpcProvider(randomRpc);
                                const arbitrumBalance =
                                    await arbitrumProvider.getBalance(
                                        this.address
                                    );

                                logger.info(
                                    `${this.accountIndex} | ${
                                        this.address
                                    } | Current Arbitrum balance: ${ethers.formatEther(
                                        arbitrumBalance
                                    )} ETH`
                                );

                                const minRequired = ethers.parseEther(
                                    this.config.bridge.eth_to_bridge[0].toString()
                                );

                                // Only proceed with withdraw if balance is actually too low
                                if (arbitrumBalance < minRequired) {
                                    const result = await this._bridge();
                                    if (!result) {
                                        continue;
                                    }
                                } else {
                                    logger.info(
                                        `${this.accountIndex} | ${this.address} | Sufficient Arbitrum balance found, proceeding with swap`
                                    );
                                }
                            }

                            // Get available tokens for swapping, excluding the highest balance token
                            const availableTokens = Object.entries(
                                SWAP_TOKENS
                            ).filter(([symbol]) => {
                                // Handle USDC.e mapping
                                const mappedSymbol =
                                    TOKEN_SYMBOL_MAPPING[
                                        highestBalanceToken.symbol
                                    ] || highestBalanceToken.symbol;
                                return symbol !== mappedSymbol;
                            });

                            if (availableTokens.length === 0) {
                                logger.error(
                                    `${this.accountIndex} | ${this.address} | No available tokens for swapping`
                                );
                                continue;
                            }

                            // Select random token from available tokens that's not the current highest balance token
                            let selectedToken;
                            do {
                                selectedToken = await randomItemFromArray(
                                    availableTokens
                                );
                            } while (
                                selectedToken[0] === highestBalanceToken.symbol
                            );

                            const toTokenSymbol = selectedToken[0];
                            const toTokenAddress = selectedToken[1];

                            // Get origin token address from SWAP_TOKENS using symbol
                            const mappedSymbol =
                                TOKEN_SYMBOL_MAPPING[
                                    highestBalanceToken.symbol
                                ] || highestBalanceToken.symbol;
                            const originTokenAddress =
                                SWAP_TOKENS[
                                    mappedSymbol as keyof typeof SWAP_TOKENS
                                ];

                            if (!originTokenAddress) {
                                logger.error(
                                    `${this.accountIndex} | ${this.address} | Could not find address for token ${highestBalanceToken.symbol} (mapped: ${mappedSymbol})`
                                );
                                continue;
                            }

                            const randomPercent = randomInt(
                                this.config.abs.balance_percent_to_swap[0],
                                this.config.abs.balance_percent_to_swap[1]
                            );
                            const amountToSwap =
                                (BigInt(highestBalanceToken.rawBalance) *
                                    BigInt(randomPercent)) /
                                BigInt(100);

                            // Log swap details in one line
                            logger.info(
                                `${this.accountIndex} | ${
                                    this.address
                                } | Swapping ${randomPercent}% (${ethers.formatUnits(
                                    amountToSwap,
                                    highestBalanceToken.decimals
                                )} ${
                                    highestBalanceToken.symbol
                                }) to ${toTokenSymbol}`
                            );

                            const jsonData = {
                                user: this.embeddedWalletAddress,
                                destinationCurrency: toTokenAddress,
                                destinationChainId: 2741,
                                originCurrency: originTokenAddress,
                                originChainId: 2741,
                                amount: amountToSwap.toString(),
                                recipient: this.embeddedWalletAddress,
                                tradeType: "EXACT_INPUT",
                                referrer: "abstract",
                                slippageTolerance: "50",
                            };

                            const response = await this.httpClient.post(
                                "https://api.relay.link/quote",
                                { json: jsonData }
                            );

                            const responseData = await response.json();
                            const steps = responseData.steps;
                            let transactions = [];
                            for (const step of steps) {
                                transactions.push(step.items[0].data);
                            }
                            let txHash;
                            for (const transaction of transactions) {
                                // Remove gasPrice and format transaction for abstractClient
                                const formattedTransaction = {
                                    to: transaction.to,
                                    value: BigInt(transaction.value || 0), // Convert to BigInt, default to 0 if undefined
                                    data: transaction.data,
                                };

                                // Send transaction with correct format
                                txHash =
                                    await this.abstractAccount.sendTransaction(
                                        formattedTransaction
                                    );
                                await sleep(2000);
                            }
                            if (txHash) {
                                success = true;
                                logger.success(
                                    `${this.accountIndex} | ${
                                        this.address
                                    } | Swap ${
                                        swapCount + 1
                                    }/${numberOfSwaps} successful: ${EXPLORER_URL}/tx/${txHash}`
                                );

                                // Wait a bit for the swap to be processed
                                await sleep(5000);

                                // Get and log updated balances after swap
                                const updatedBalances =
                                    await this._getAbsWalletBalances();
                                if (updatedBalances) {
                                    logger.info(
                                        `${this.accountIndex} | ${
                                            this.address
                                        } | Updated balances after swap ${
                                            swapCount + 1
                                        }: ${this.formatBalances(
                                            updatedBalances
                                        )}`
                                    );
                                }

                                // Add random pause between swaps if this isn't the last swap
                                if (swapCount < numberOfSwaps - 1) {
                                    const pauseTime = randomInt(
                                        this.config.settings
                                            .random_pause_between_swaps[0],
                                        this.config.settings
                                            .random_pause_between_swaps[1]
                                    );
                                    logger.info(
                                        `${this.accountIndex} | ${this.address} | Waiting ${pauseTime} seconds before next swap...`
                                    );
                                    await sleep(pauseTime * 1000);
                                }
                                break;
                            }
                        } catch (error) {
                            if (attempt < 2) {
                                logger.error(
                                    `${this.accountIndex} | ${
                                        this.address
                                    } | Swap attempt ${
                                        attempt + 1
                                    } failed, retrying... Error: ${error}`
                                );
                                await sleep(2000); // Wait before retry
                            } else {
                                logger.error(
                                    `${this.accountIndex} | ${
                                        this.address
                                    } | All swap attempts failed for swap ${
                                        swapCount + 1
                                    }/${numberOfSwaps}. Error: ${error}`
                                );
                            }
                        }
                    }

                    if (!success) {
                        logger.error(
                            `${this.accountIndex} | ${
                                this.address
                            } | Failed to perform swap ${
                                swapCount + 1
                            }/${numberOfSwaps} after 3 attempts`
                        );
                        return false;
                    }
                }

                // Get and log final balances
                const finalBalances = await this._getAbsWalletBalances();
                if (finalBalances) {
                    logger.info(
                        `${this.accountIndex} | ${
                            this.address
                        } | Final balances after all swaps: ${this.formatBalances(
                            finalBalances
                        )}`
                    );
                }

                return true;
            } catch (error) {
                logger.error(
                    `${this.accountIndex} | ${this.address} | Error in swaps: ${error}`
                );
                return false;
            }
        }, "Swaps");
    }

    async badges(): Promise<boolean> {
        return await this.retryOperation(async () => {
            try {
                const userInfo = await this._getUserInfo();
                const badges = userInfo.user.badges;
                if (badges.length === 0) {
                    logger.info(
                        `${this.accountIndex} | ${this.address} | No available badges for claiming`
                    );
                    return true;
                }

                for (const badge of badges) {
                    if (!badge.claimed) {
                        logger.info(
                            `${this.accountIndex} | ${this.address} | Claiming badge: ${badge.badge.name}`
                        );
                        const badgeABI = JSON.parse(
                            fs.readFileSync("src/abis/absBadgeAbi.json", "utf8")
                        );
                        const contract = new ethers.Interface(badgeABI);

                        const response = await this.httpClient.post(
                            `https://backend.portal.abs.xyz/api/badge/${badge.badge.id.toString()}/claim`,
                            {
                                headers: {
                                    accept: "application/json, text/plain, */*",
                                    authorization: `Bearer ${this.loginTokens.bearer_token}`,
                                    origin: "https://www.abs.xyz",
                                    referer: "https://www.abs.xyz/",
                                    "x-privy-token":
                                        this.loginTokens.identity_token,
                                },
                                json: {},
                            }
                        );
                        if (!response.ok) {
                            throw new Error(
                                `Failed to claim badge: ${await response.text()}`
                            );
                        }
                        const data = await response.json();
                        const signature = data.signature;

                        logger.info(
                            `${this.accountIndex} | ${this.address} | Minting badge to address: ${this.embeddedWalletAddress}`
                        );

                        const encodedBadgeData = contract.encodeFunctionData(
                            "mintBadge",
                            [
                                this.embeddedWalletAddress,
                                badge.badge.id,
                                signature,
                            ]
                        );
                        const transaction = {
                            to: ABS_BADGE_CONTRACT,
                            data: encodedBadgeData,
                            value: 0,
                        };

                        const txHash =
                            await this.abstractAccount.sendTransaction(
                                transaction
                            );
                        if (txHash) {
                            logger.success(
                                `${this.accountIndex} | ${this.address} | Successfully minted ${badge.badge.name} | https://abscan.org/tx/${txHash}`
                            );
                        }
                    }
                }

                return true;
            } catch (error) {
                logger.error(
                    `${this.accountIndex} | ${this.address} | Error badges: ${error}`
                );
                return false;
            }
        }, "Badges");
    }

    /**
     * Connect social accounts
     */
    public async connectSocials(): Promise<boolean> {
        return await this.retryOperation(async () => {
            try {
                let connectDiscord = true;
                let connectTwitter = true;

                const userInfo = await this._getUserInfo();
                const socials = userInfo.user.socials;

                for (const [social, username] of Object.entries(socials)) {
                    if (social === "discord") {
                        logger.success(
                            `${this.accountIndex} | ${this.address} | Discord ${username} already connected!`
                        );
                        connectDiscord = false;
                    } else if (social === "twitter") {
                        logger.success(
                            `${this.accountIndex} | ${this.address} | Twitter ${username} already connected!`
                        );
                        connectTwitter = false;
                    }
                }

                if (connectDiscord) {
                    if (!(await this._connectDiscord())) {
                        return false;
                    }
                }

                // Commented out as in the Python code
                if (connectTwitter) {
                    if (!(await this._connectTwitter())) {
                        return false;
                    }
                }

                return true;
            } catch (error) {
                logger.error(
                    `${this.accountIndex} | ${this.address} | Error connect socials: ${error}`
                );
                return false;
            }
        }, "Connect socials");
    }

    // Update the votes method to use _getMyVotes
    public async votes(): Promise<boolean> {
        return await this.retryOperation(async () => {
            try {
                const myVotes = await this._getMyVotes();
                if (!myVotes) {
                    logger.error(
                        `${this.accountIndex} | ${this.address} | Failed to get voted apps`
                    );
                    return false;
                }

                interface App {
                    id: string;
                    name: string;
                }

                let page = 1;
                let allApps: App[] = [];
                while (true) {
                    const response = await this.httpClient.get(
                        `https://backend.portal.abs.xyz/api/app?page=${page}&limit=20&category=`,
                        {
                            headers: {
                                accept: "application/json, text/plain, */*",
                                authorization: `Bearer ${this.loginTokens.bearer_token}`,
                                origin: "https://www.abs.xyz",
                                referer: "https://www.abs.xyz/",
                                "x-privy-token":
                                    this.loginTokens.identity_token,
                            },
                        }
                    );
                    const data = await response.json();

                    // Extract id and name from each app in the response
                    const apps: App[] = data.items.map((item: any) => ({
                        id: item.id,
                        name: item.name,
                    }));

                    // Add apps from this page to our collection
                    allApps = [...allApps, ...apps];

                    if (data.pagination.totalPages === page) {
                        break;
                    }
                    page++;
                }

                logger.info(
                    `${this.accountIndex} | ${this.address} | Already voted apps: ${myVotes}`
                );
                // Filter out apps that have already been voted for
                const unvotedApps = allApps.filter(
                    (app) => !myVotes.includes(Number(app.id))
                );

                logger.info(
                    `${this.accountIndex} | ${this.address} | Found ${unvotedApps.length} unvoted apps`
                );

                const randomApp = await randomItemFromArray(unvotedApps);

                logger.info(
                    `${this.accountIndex} | ${this.address} | Voting for ${randomApp.name} | ID: ${randomApp.id}`
                );

                const voteABI = JSON.parse(
                    fs.readFileSync("src/abis/absVoteAbi.json", "utf8")
                );
                const contractInterface = new ethers.Interface(voteABI);

                const encodedTransactionData =
                    contractInterface.encodeFunctionData("voteForApp", [
                        randomApp.id,
                    ]);
                const transaction = {
                    to: ABS_VOTE_CONTRACT,
                    data: encodedTransactionData,
                    value: 0,
                };

                try {
                    const txHash = await this.abstractAccount.sendTransaction(
                        transaction
                    );

                    if (txHash) {
                        logger.success(
                            `${this.accountIndex} | ${this.address} | Successfully voted for ${randomApp.name} app | TX: ${EXPLORER_URL}${txHash}`
                        );
                        return true;
                    }
                } catch (error) {
                    logger.error(
                        `${this.accountIndex} | ${this.address} | Error voting for ${randomApp.name} app: ${error}`
                    );
                    return true;
                }

                return true;
            } catch (error) {
                logger.error(
                    `${this.accountIndex} | ${this.address} | Error votes: ${error}`
                );
                return false;
            }
        }, "Votes");
    }

    async withdraw(): Promise<boolean | Record<string, any>> {
        try {
            if (this.config.withdraw.cex === "okx") {
                const withdrawal = new OKXWithdraw(
                    this.accountIndex,
                    this.privateKey,
                    this.config
                );
                return await withdrawal.withdraw();
            } else if (this.config.withdraw.cex === "bitget") {
                const withdrawal = new BitgetWithdraw(
                    this.accountIndex,
                    this.privateKey,
                    this.config
                );
                return await withdrawal.withdraw();
            }

            return false;
        } catch (error) {
            logger.error(`${this.address} | Error withdraw: ${error}`);
            return false;
        }
    }

    async _bridge(): Promise<boolean> {
        try {
            // Check Arbitrum ETH balance
            const randomRpc = getRandomRpc(this.config.rpcs.arbitrum_rpc);
            const arbitrumProvider = new ethers.JsonRpcProvider(randomRpc);
            const arbitrumBalance = await arbitrumProvider.getBalance(
                this.address
            );

            const minRequired = ethers.parseEther(
                this.config.bridge.eth_to_bridge[0].toString()
            );

            // If balance is too low, withdraw first
            if (arbitrumBalance < minRequired) {
                logger.info(
                    `${this.accountIndex} | ${
                        this.address
                    } | Arbitrum balance is too low ${ethers.formatEther(
                        arbitrumBalance
                    )} ETH, withdrawing...`
                );

                const withdrawResult = await this.withdraw();
                if (!withdrawResult) {
                    return false;
                }

                // Wait for 30 seconds after withdrawal
                logger.info(
                    `${this.accountIndex} | ${this.address} | Waiting 30 seconds after withdrawal...`
                );
                await sleep(30000);

                // Check balance again
                const newBalance = await arbitrumProvider.getBalance(
                    this.address
                );
                if (newBalance < minRequired) {
                    logger.error(
                        `${this.accountIndex} | ${
                            this.address
                        } | Balance still too low after withdrawal: ${ethers.formatEther(
                            newBalance
                        )} ETH`
                    );
                    return false;
                }

                // Proceed with bridge using new balance
                logger.success(
                    `${this.accountIndex} | ${
                        this.address
                    } | New Arbitrum balance after withdrawal: ${ethers.formatEther(
                        newBalance
                    )} ETH, proceeding with bridge`
                );

                // Calculate amount to bridge (95% of new balance)
                const amountToBridge = (newBalance * BigInt(95)) / BigInt(100);
                return await this._executeBridge(amountToBridge);
            } else {
                logger.success(
                    `${this.accountIndex} | ${
                        this.address
                    } | Arbitrum balance is ${ethers.formatEther(
                        arbitrumBalance
                    )} ETH, proceeding with bridge`
                );

                // Calculate amount to bridge (95% of balance)
                const amountToBridge =
                    (arbitrumBalance * BigInt(95)) / BigInt(100);
                return await this._executeBridge(amountToBridge);
            }
        } catch (error) {
            logger.error(`${this.address} | Error bridge: ${error}`);
            return false;
        }
    }

    // Helper method to execute the bridge
    private async _executeBridge(amount: bigint): Promise<boolean> {
        logger.info(
            `${this.accountIndex} | ${
                this.address
            } | Trying to bridge ${ethers.formatEther(
                amount
            )} ETH from Arbitrum to Abstract`
        );

        const bridge = new RelayBridge(
            this.accountIndex,
            this.proxy,
            this.privateKey,
            this.config,
            this.embeddedWalletAddress
        );

        let quoteResult = await bridge.quote(amount.toString());
        if (!quoteResult) {
            return false;
        }

        let bridgeResult = await bridge.bridge();
        if (!bridgeResult) {
            return false;
        }

        logger.success(
            `${this.accountIndex} | ${this.address} | Successfully bridged ETH from Arbitrum to Abstract`
        );

        // Wait 30 seconds after successful bridge
        logger.info(
            `${this.accountIndex} | ${this.address} | Waiting 30 seconds after bridge...`
        );
        await sleep(30000);

        return true;
    }

    /**
     * Get user's votes
     */
    private async _getMyVotes(): Promise<[number] | null> {
        try {
            const headers = {
                accept: "application/json, text/plain, */*",
                authorization: `Bearer ${this.loginTokens.bearer_token}`,
                origin: "https://www.abs.xyz",
                referer: "https://www.abs.xyz/",
                "x-privy-token": this.loginTokens.identity_token,
            };

            const response = await this.httpClient.get(
                `https://backend.portal.abs.xyz/api/user/${this.embeddedWalletAddress}/votes`,
                { headers }
            );

            if (!response.ok) {
                throw new Error(
                    `Failed to get user votes: ${await response.text()}`
                );
            }

            const data = await response.json();
            return data.votedApps;
        } catch (error) {
            logger.error(
                `${this.accountIndex} | ${this.address} | Error get my votes: ${error}`
            );
            return null;
        }
    }

    /**
     * Get nonce for signing
     */
    private async _getNonce(): Promise<string> {
        try {
            const headers = {
                accept: "application/json",
                origin: "https://www.abs.xyz",
                "privy-app-id": PRIVY_APP_ID,
                "privy-client-id": PRIVY_CLIENT_ID,
                referer: "https://www.abs.xyz/",
            };

            const jsonData = {
                address: this.address,
            };

            const response = await this.httpClient.post(
                "https://auth.privy.io/api/v1/siwe/init",
                { headers, json: jsonData }
            );

            if (!response.ok) {
                throw new Error(
                    `Failed to get nonce: ${await response.text()}`
                );
            }

            const { nonce } = await response.json();
            return nonce;
        } catch (error) {
            logger.error(
                `${this.accountIndex} | ${this.address} | Error get nonce: ${error}`
            );
            throw error;
        }
    }

    /**
     * Refresh session
     */
    private async _refreshSession(): Promise<boolean> {
        try {
            const headers = {
                accept: "application/json",
                authorization: `Bearer ${this.loginTokens.privy_access_token}`,
                origin: "https://www.abs.xyz",
                "privy-app-id": PRIVY_APP_ID,
                "privy-client-id": PRIVY_CLIENT_ID,
                referer: "https://www.abs.xyz/",
            };

            const jsonData = {
                refresh_token: this.loginTokens.refresh_token,
            };

            const response = await this.httpClient.post(
                "https://auth.privy.io/api/v1/sessions",
                { headers, json: jsonData }
            );

            const data = await response.json();

            this.loginTokens.identity_token = data.identity_token;
            return true;
        } catch (error) {
            logger.error(
                `${this.accountIndex} | ${this.address} | Error refresh session: ${error}`
            );
            return false;
        }
    }

    // Create embedded wallet
    private async _createEmbeddedWallet(): Promise<boolean> {
        try {
            const headers = {
                accept: "application/json",
                authorization: `Bearer ${this.loginTokens.privy_access_token}`,
                origin: "https://auth.privy.io",
                "privy-app-id": PRIVY_APP_ID,
                "privy-client-id": PRIVY_CLIENT_ID,
                referer: "https://auth.privy.io/",
            };

            const jsonData = {
                address: this.address,
                chain_type: "ethereum",
            };

            const response = await this.httpClient.post(
                "https://auth.privy.io/api/v1/embedded_wallets/init",
                { headers, json: jsonData }
            );

            if (!response.ok) {
                throw new Error(
                    `Failed to get embedded wallets: ${await response.text()}`
                );
            }

            const { nonce } = await response.json();
            const date = new Date();
            const currentTime =
                date.getUTCFullYear() +
                "-" +
                String(date.getUTCMonth() + 1).padStart(2, "0") +
                "-" +
                String(date.getUTCDate()).padStart(2, "0") +
                "T" +
                String(date.getUTCHours()).padStart(2, "0") +
                ":" +
                String(date.getUTCMinutes()).padStart(2, "0") +
                ":" +
                String(date.getUTCSeconds()).padStart(2, "0") +
                ".604Z";

            const message =
                `auth.privy.io wants you to sign in with your Ethereum account:\n` +
                `${this.address}\n\n` +
                `You are proving you own ${this.address}.\n\n` +
                `URI: https://auth.privy.io\n` +
                `Version: 1\n` +
                `Chain ID: 1\n` +
                `Nonce: ${nonce}\n` +
                `Issued At: ${currentTime}\n` +
                `Resources:\n` +
                `- https://privy.io`;

            const signature = await this.wallet.signMessage(message);

            const deviceData = this._generateRandomDeviceData();

            const createWalletData = {
                chain_type: "ethereum",
                message,
                signature: signature,
                ...deviceData,
            };

            const createResponse = await this.httpClient.post(
                "https://auth.privy.io/api/v1/embedded_wallets",
                { headers, json: createWalletData }
            );

            if (!createResponse.ok) {
                throw new Error(
                    `Failed to create embedded wallet: ${await createResponse.text()}`
                );
            }

            if (!(await this._refreshSession())) {
                return false;
            }

            logger.success(
                `${this.accountIndex} | ${this.address} | Successfully created embedded wallet!`
            );

            return true;
        } catch (error) {
            logger.error(
                `${this.accountIndex} | ${this.address} | Error creating embedded wallet: ${error}`
            );
            return false;
        }
    }

    /**
     * Generate random device data
     */
    private _generateRandomDeviceData(): DeviceData {
        const generateBase64 = (length: number): string => {
            const randomBytes = crypto.randomBytes(length);
            return randomBytes.toString("base64").slice(0, length);
        };

        const generateAlphanumeric = (length: number): string => {
            const chars =
                "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
            return Array.from(
                crypto.randomBytes(length),
                (byte) => chars[byte % chars.length]
            ).join("");
        };

        return {
            device_id: generateAlphanumeric(20),
            device_auth_share: generateBase64(20) + "=",
            recovery_auth_share: generateBase64(20) + "=",
            encrypted_recovery_share: generateBase64(40),
            encrypted_recovery_share_iv: generateBase64(12) + "/",
            recovery_type: "privy_generated_recovery_key",
            recovery_key_hash: generateBase64(40) + "=",
            imported: false,
            recovery_key: generateBase64(40) + "=",
        };
    }

    /**
     * Get ABS wallet balances
     */
    public async _getAbsWalletBalances(): Promise<AbsBalance[] | null> {
        try {
            const headers = {
                accept: "application/json, text/plain, */*",
                authorization: `Bearer ${this.loginTokens.bearer_token}`,
                origin: "https://www.abs.xyz",
                referer: "https://www.abs.xyz/",
                "x-privy-token": this.loginTokens.identity_token,
            };

            const response = await this.httpClient.get(
                `https://backend.portal.abs.xyz/api/user/${this.embeddedWalletAddress}/wallet/balances`,
                { headers }
            );

            if (!response.ok) {
                throw new Error(
                    `Failed to get abs wallet balances: ${await response.text()}`
                );
            }

            const data = await response.json();
            const allBalances: AbsBalance[] = data.tokens.map((token: any) => ({
                name: token.name,
                symbol: token.symbol,
                decimals: token.decimals,
                rawBalance: token.balance.raw,
                decimalBalance: token.balance.decimal,
                usdValue: token.usdValue,
            }));

            return allBalances;
        } catch (error) {
            logger.error(
                `${this.accountIndex} | ${this.address} | Error get abs wallet balances: ${error}`
            );
            return null;
        }
    }

    /**
     * Connect Discord account
     */
    private async _connectDiscord(): Promise<boolean> {
        for (
            let retry = 0;
            retry < this.config.settings.tasks_attempts;
            retry++
        ) {
            try {
                const headers = {
                    accept: "application/json, text/plain, */*",
                    authorization: `Bearer ${this.loginTokens.bearer_token}`,
                    origin: "https://www.abs.xyz",
                    referer: "https://www.abs.xyz/",
                    "x-privy-token": this.loginTokens.identity_token,
                };

                const jsonData = {
                    isInitialFlow: false,
                };

                const response = await this.httpClient.post(
                    "https://backend.portal.abs.xyz/api/social/discord",
                    { headers, json: jsonData }
                );

                if (!response.ok) {
                    throw new Error(
                        `Failed to init discord connect: ${await response.text()}`
                    );
                }

                const { authUrl } = await response.json();
                const url = new URL(authUrl);
                const state = decodeURIComponent(
                    url.searchParams.get("state") || ""
                );
                const clientId = url.searchParams.get("client_id");

                if (!clientId) {
                    throw new Error("Failed to get client_id from auth URL");
                }

                const discordHeaders = {
                    accept: "*/*",
                    "accept-language":
                        "en-GB,en-US;q=0.9,en;q=0.8,ru;q=0.7,zh-TW;q=0.6,zh;q=0.5",
                    authorization: this.discordToken,
                    origin: "https://discord.com",
                    referer: `https://discord.com/oauth2/authorize?response_type=code&client_id=${clientId}&redirect_uri=https%3A%2F%2Fbackend.portal.abs.xyz%2Fapi%2Fsocial%2Fdiscord%2Fcallback&state=${state}`,
                    "x-debug-options": "bugReporterEnabled",
                    "x-discord-locale": "en-US",
                    "x-discord-timezone": "Etc/GMT-2",
                };

                const discordJsonData = {
                    authorize: true,
                    integration_type: 0,
                    location_context: {
                        channel_id: "10000",
                        channel_type: 10000,
                        guild_id: "10000",
                    },
                    permissions: "0",
                };

                const params = {
                    client_id: clientId as string,
                    response_type: "code",
                    redirect_uri:
                        "https://backend.portal.abs.xyz/api/social/discord/callback",
                    scope: "identify guilds guilds.members.read",
                    state: state,
                };

                const discordResponse = await this.httpClient.post(
                    `https://discord.com/api/v9/oauth2/authorize?${new URLSearchParams(
                        params
                    )}`,
                    {
                        headers: discordHeaders,
                        json: discordJsonData,
                    }
                );

                if (!discordResponse.ok) {
                    throw new Error(
                        `Failed to authorize discord: ${await discordResponse.text()}`
                    );
                }

                const { location } = await discordResponse.json();
                const finalResponse = await this.httpClient.get(location);

                if (!finalResponse.ok) {
                    throw new Error(
                        `Failed to connect discord: ${await finalResponse.text()}`
                    );
                }

                logger.success(
                    `${this.accountIndex} | ${this.address} | Successfully connected discord!`
                );
                return true;
            } catch (error) {
                logger.error(
                    `${this.accountIndex} | ${this.address} | RETRY ${
                        retry + 1
                    }/${
                        this.config.settings.tasks_attempts
                    } | Error connect discord: ${error}`
                );
                const randomPause = Math.floor(
                    Math.random() *
                        (this.config.settings.pause_between_attempts[1] -
                            this.config.settings.pause_between_attempts[0]) +
                        this.config.settings.pause_between_attempts[0]
                );
                logger.info(
                    `${this.accountIndex} | ${this.address} | Pausing for ${randomPause} seconds...`
                );
                await new Promise((resolve) =>
                    setTimeout(resolve, randomPause * 1000)
                );
            }
        }

        return false;
    }

    /**
     * Connect Twitter account
     */
    private async _connectTwitter(): Promise<boolean> {
        try {
            let headers = {
                accept: "application/json, text/plain, */*",
                authorization: `Bearer ${this.loginTokens.bearer_token}`,
                origin: "https://www.abs.xyz",
                referer: "https://www.abs.xyz/",
                "x-privy-token": this.loginTokens.identity_token,
            };
            let response = await this.httpClient.post(
                `https://backend.portal.abs.xyz/api/social/twitter`,
                { json: { isInitialFlow: false }, headers: headers }
            );
            if (!response.ok) {
                throw new Error(
                    `Failed to get twitter connection link: ${await response.text()}`
                );
            }

            let responseData = await response.json();
            const twitterAuthUrl = responseData["authUrl"];

            // Parse the Twitter auth URL
            const parsedUrl = new URL(twitterAuthUrl);
            const params = {
                responseType: parsedUrl.searchParams.get("response_type"),
                clientId: parsedUrl.searchParams.get("client_id"),
                redirectUri: parsedUrl.searchParams.get("redirect_uri"),
                scope: parsedUrl.searchParams.get("scope"),
                state: parsedUrl.searchParams.get("state"),
                codeChallenge: parsedUrl.searchParams.get("code_challenge"),
                codeChallengeMethod: parsedUrl.searchParams.get(
                    "code_challenge_method"
                ),
            };

            // Construct the Twitter API OAuth URL with our parsed params
            const twitterApiUrl = `https://twitter.com/i/api/2/oauth2/authorize?client_id=${encodeURIComponent(
                params.clientId!
            )}&code_challenge=${encodeURIComponent(
                params.codeChallenge!
            )}&code_challenge_method=${encodeURIComponent(
                params.codeChallengeMethod!
            )}&redirect_uri=${encodeURIComponent(
                params.redirectUri!
            )}&response_type=${encodeURIComponent(
                params.responseType!
            )}&scope=${encodeURIComponent(
                params.scope!
            )}&state=${encodeURIComponent(params.state!)}`;

            let csrfToken = generateCsrfToken();

            let twitterHeaders = {
                authorization:
                    "Bearer AAAAAAAAAAAAAAAAAAAAANRILgAAAAAAnNwIzUejRCOuH5E6I8xnZz4puTs%3D1Zv7ttfk8LF81IUq16cHjhLTvJu4FA33AGWWjCpTnA",
                accept: "*/*",
                "accept-language": "ru-RU,ru;q=0.8",
                cookie: `lang=en; auth_token=${this.twitterToken}; ct0=${csrfToken};`,
                "content-type": "application/x-www-form-urlencoded",
                "referrer-policy": "strict-origin-when-cross-origin",
                "x-twitter-active-user": "yes",
                "x-twitter-auth-type": "OAuth2Session",
                "x-twitter-client-language": "en",
                "x-csrf-token": csrfToken,
            };

            // Make request to Twitter API OAuth endpoint
            const twitterResponse = await this.httpClient.get(twitterApiUrl, {
                headers: twitterHeaders,
            });

            if (!twitterResponse.ok) {
                throw new Error(
                    `Failed to authorize with Twitter: ${await twitterResponse.text()}`
                );
            }

            responseData = await twitterResponse.json();
            const authCode = responseData["auth_code"];
            logger.success(
                `${this.accountIndex} | ${this.address} | Got twitter auth code: ${authCode}`
            );

            responseData = await this.httpClient.post(
                `https://twitter.com/i/api/2/oauth2/authorize`,
                {
                    json: {
                        approval: true,
                        code: authCode,
                    },
                    headers: twitterHeaders,
                }
            );

            if (!responseData.ok) {
                throw new Error(
                    `Failed to connect twitter: ${await responseData.text()}`
                );
            }
            const redirectUrlData = await responseData.json();
            const redirectUrl = redirectUrlData["redirect_uri"];

            responseData = await this.httpClient.get(redirectUrl, {
                headers: twitterHeaders,
            });

            if (!responseData.ok) {
                throw new Error(
                    `Failed to connect twitter: ${await responseData.text()}`
                );
            }
            logger.success(
                `${this.accountIndex} | ${this.address} | Successfully connected twitter!`
            );

            return true;
        } catch (error) {
            logger.error(
                `${this.accountIndex} | ${this.address} | Error connect twitter: ${error}`
            );
            return false;
        }
    }

    /**
     * Get user info
     */
    private async _getUserInfo(): Promise<UserInfo> {
        try {
            const headers = {
                accept: "application/json, text/plain, */*",
                authorization: `Bearer ${this.loginTokens.bearer_token}`,
                origin: "https://www.abs.xyz",
                referer: "https://www.abs.xyz/",
                "x-privy-token": this.loginTokens.identity_token,
            };

            const response = await this.httpClient.post(
                "https://backend.portal.abs.xyz/api/user",
                { headers, json: {} }
            );

            if (!response.ok) {
                throw new Error(
                    `Failed to get user info: ${await response.text()}`
                );
            }

            return await response.json();
        } catch (error) {
            logger.error(
                `${this.accountIndex} | ${this.address} | Error get user info: ${error}`
            );
            throw error;
        }
    }
}
