import { Browser, BrowserContext, Page, chromium } from "playwright";
import { sleep } from "../../utils/random.js";
import logger from "../../utils/logger.js";
import path from "path";
import { mkdtemp } from "fs/promises";
import os from "os";
import clipboardy from "clipboardy";

export class PrivateKeyGrabber {
    private browser: Browser | null = null;
    private context: BrowserContext | null = null;
    private page: Page | null = null;
    metamaskLoginPage: Page | undefined;

    constructor(
        private accountIndex: number,
        private proxy: string | null = null,
        private privateKey: string
    ) {}

    async _init(): Promise<boolean> {
        try {
            const metamask = path.resolve("src/utils/metamask_extension");
            const pwTempDir = await mkdtemp(
                path.join(os.tmpdir(), "playwright_tempdata_")
            );

            const args = [
                "--disable-blink-features=AutomationControlled",
                `--disable-extensions-except=${metamask}`,
                `--load-extension=${metamask}`,
                "--enable-javascript-harmony",
                "--disable-features=IsolateOrigins,site-per-process",
                "--lang=en-US",
                "--disable-dev-shm-usage",
                "--no-sandbox",
                "--disable-infobars",
                "--start-maximized",
                "--allow-running-insecure-content",
            ];

            let proxy;
            if (this.proxy) {
                const ok = this.proxy.match(/([^:]+):([^@]+)@(.+)/);
                if (ok) {
                    proxy = {
                        server: `http://${ok[3]}`,
                        username: ok[1],
                        password: ok[2],
                    };
                }
            }

            this.context = await chromium.launchPersistentContext(pwTempDir, {
                headless: false,
                proxy: proxy,
                locale: "en-US",
                timezoneId: "Europe/Berlin",
                javaScriptEnabled: true,
                channel: "chrome",
                viewport: { width: 1080, height: 920 },
                userAgent:
                    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36",
                args,
            });

            this.page = await this.context.newPage();

            logger.info(
                `${this.accountIndex} | Browser initialized successfully`
            );

            return true;
        } catch (error) {
            logger.error(
                `${this.accountIndex} | Error initializing browser: ${error}`
            );
            return false;
        }
    }

    async grabPrivateKey(): Promise<string> {
        try {
            let ok = await this._init();
            if (!ok) {
                return "";
            }

            await this.page?.goto("https://www.abs.xyz/login");
            await sleep(12000);

            this.metamaskLoginPage = this.context?.pages()[2];
            if (!this.metamaskLoginPage) {
                return "";
            }

            ok = await this._loginMetamask();
            if (!ok) {
                return "";
            }

            ok = await this._loginAbs();
            if (!ok) {
                return "";
            }

            return await this._getPrivateKey();
        } catch (error) {
            logger.error(
                `${this.accountIndex} | Error grabbing private key: ${error}`
            );
            return "";
        } finally {
            await this.cleanup();
        }
    }
    async _loginMetamask(): Promise<boolean> {
        try {
            await sleep(4000);
            // Click "Get Started" button
            await this.metamaskLoginPage?.click(
                "xpath=/html/body/div[1]/div/div[2]/div/div/div/ul/li[1]/div/input"
            );
            await sleep(1000);
            await this.metamaskLoginPage?.click(
                "xpath=/html/body/div[1]/div/div[2]/div/div/div/ul/li[2]/button"
            );
            await sleep(1000);
            await this.metamaskLoginPage?.click(
                "xpath=/html/body/div[1]/div/div[2]/div/div/div/div[2]/button[2]"
            );
            await sleep(1000);

            await this.metamaskLoginPage?.fill(
                "xpath=/html/body/div[1]/div/div[2]/div/div/div/div[2]/form/div[1]/label/input",
                "00000000"
            );
            await this.metamaskLoginPage?.fill(
                "xpath=/html/body/div[1]/div/div[2]/div/div/div/div[2]/form/div[2]/label/input",
                "00000000"
            );

            // Click through import flow
            await this.metamaskLoginPage?.click(
                "xpath=/html/body/div[1]/div/div[2]/div/div/div/div[2]/form/div[3]/label/span[1]/input"
            );
            await sleep(1000);
            await this.metamaskLoginPage?.click(
                "xpath=/html/body/div[1]/div/div[2]/div/div/div/div[2]/form/button"
            );
            await sleep(1000);
            await this.metamaskLoginPage?.click(
                "xpath=/html/body/div[1]/div/div[2]/div/div/div/div[2]/button[1]"
            );
            await sleep(1000);
            await this.metamaskLoginPage?.click(
                "xpath=/html/body/div[2]/div/div/section/div[1]/div/div/label/input"
            );
            await sleep(1000);
            await this.metamaskLoginPage?.click(
                "xpath=/html/body/div[2]/div/div/section/div[2]/div/button[2]"
            );
            await sleep(1000);
            await this.metamaskLoginPage?.click(
                "xpath=/html/body/div[1]/div/div[2]/div/div/div/div[3]/button"
            );
            await sleep(1000);
            await this.metamaskLoginPage?.click(
                "xpath=/html/body/div[1]/div/div[2]/div/div/div/div[2]/button"
            );
            await sleep(1000);
            await this.metamaskLoginPage?.click(
                "xpath=/html/body/div[1]/div/div[2]/div/div/div/div[2]/button"
            );
            await sleep(1000);
            await this.metamaskLoginPage?.click(
                "xpath=/html/body/div[1]/div/div[2]/div/div[2]/button"
            );
            await sleep(1000);
            await this.metamaskLoginPage?.click(
                "xpath=/html/body/div[3]/div[3]/div/section/div[2]/button"
            );
            await sleep(1000);
            await this.metamaskLoginPage?.click(
                "xpath=/html/body/div[3]/div[3]/div/section/div/div[2]/button"
            );
            await sleep(1000);

            await this.metamaskLoginPage?.fill(
                "xpath=/html/body/div[3]/div[3]/div/section/div/div/div[1]/div/input",
                this.privateKey
            );
            await sleep(2000);
            await this.metamaskLoginPage?.click(
                "xpath=/html/body/div[3]/div[3]/div/section/div/div/div[2]/button[2]"
            );
            await this.metamaskLoginPage?.close();

            await sleep(1000);

            return true;
        } catch (error) {
            logger.error(
                `${this.accountIndex} | Error logging in to metamask: ${error}`
            );
            return false;
        }
    }

    async _loginAbs(): Promise<boolean> {
        try {
            await this.page?.reload();
            await sleep(3000);

            // Click "Login with Wallet"
            await this.page?.click('button:has-text("Login with Wallet")');
            await sleep(2000);

            // Click "MetaMask"
            await this.page?.click('button:has-text("MetaMask")');
            await sleep(3000);

            // Switch to MetaMask and click Connect
            this.metamaskLoginPage = this.context?.pages()[2];

            if (this.metamaskLoginPage) {
                await this.metamaskLoginPage.click(
                    'button[data-testid="confirm-btn"]'
                );
                await sleep(2000);

                // Click Confirm in MetaMask
                await this.metamaskLoginPage.click(
                    'button:has-text("Confirm")'
                );
                await sleep(3000);
            }

            try {
                // Back to main page and click Skip
                await this.page?.click('button:has-text("Skip")');
            } catch {}

            return true;
        } catch (error) {
            logger.error(
                `${this.accountIndex} | Error logging in to abs: ${error}`
            );
            return false;
        }
    }

    async _getPrivateKey(): Promise<string> {
        try {
            await this.page?.goto("https://www.abs.xyz/profile");
            await sleep(3000);

            // Click Security tab
            await this.page?.click('h3:has-text("Security")');
            await sleep(2000);

            // Click Export button
            await this.page?.click('button:has-text("Export")');
            await sleep(2000);

            // Confirm export
            await this.page?.click('button:has-text("Yes, export")');
            await sleep(5000);

            // Click Copy Key button and get clipboard content
            for (let i = 0; i < 4; i++) {
                await this.page?.keyboard.press("Tab");
                await sleep(1000);
            }
            await this.page?.keyboard.press("Enter");
            await sleep(1000);

            const privateKey = clipboardy.readSync();
            if (privateKey) {
                logger.info(
                    `${this.accountIndex} | Successfully got private key: 0x${privateKey}`
                );
                return "0x" + privateKey;
            } else {
                return "";
            }
        } catch (error) {
            logger.error(
                `${this.accountIndex} | Error getting private key: ${error}`
            );
            return "";
        }
    }
    private async cleanup(): Promise<void> {
        if (this.page) await this.page.close();
        if (this.context) await this.context.close();
        if (this.browser) await this.browser.close();
    }
}
